__all__ = ["DoceboRestClient"]

from dbacademy.clients.docebo.docebo_rest_client_class import DoceboRestClient
